package repo;

public interface Datastruct {
    int getID();
    void setID(int id);
    String getDescription();
    void setDescription(String str);
}