package repo;

public class ExistingException extends Exception{
    public ExistingException(){
        super();
    }

    public ExistingException(String msg){
        super(msg);
    }
}
