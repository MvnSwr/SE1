package repo;

public class CardboxStorageException extends Exception{
    public CardboxStorageException(){
        super();
    }

    public CardboxStorageException(String msg){
        super(msg);
    }
}